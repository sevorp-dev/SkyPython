# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.14",
        python_install_dir=r"/usr/local/lib/python3.14/site-packages/",
        python_path=r"/tmp/cibw-run-1pcj0fkp/cp314-android_x86/venv/bin/python",

        # Package versions
        contourpy_version="1.4.0",
        meson_version="1.12.1",
        mesonpy_version="0.22.1",
        pybind11_version="3.1.0",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/home/runner/work/SkyPython/SkyPython/src/.mesonpy-r7ksjt9d/lib/contourpy/util",
        source_dir=r"/home/runner/work/SkyPython/SkyPython/src/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=true -Dwerror=false '-Dcpp_link_args=['-static-libstdc++', '-Wl,--build-id=sha1', '-Wl,--no-rosegment', '-Wl,-z,max-page-size=16384', '-Wl,--no-undefined', '-lm']' --cross-file=/home/runner/work/SkyPython/SkyPython/src/.mesonpy-r7ksjt9d/meson-python-cross-file.ini --native-file=/home/runner/work/SkyPython/SkyPython/src/.mesonpy-r7ksjt9d/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="18.0.4",
        linker_id="ld.lld",
        compile_command="/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/bin/i686-linux-android24-clang++",

        # Host machine
        host_cpu="i686",
        host_cpu_family="x86",
        host_cpu_endian="little",
        host_cpu_system="android",

        # Build machine, same as host machine if not a cross_build
        build_cpu="i686",
        build_cpu_family="x86",
        build_cpu_endian="little",
        build_cpu_system="android",
    )
